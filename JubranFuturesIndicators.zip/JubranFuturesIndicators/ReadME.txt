


انقل الملفات الى

C:\Users\( YOUR PC NAME )\Documents\NinjaTrader 8\bin\Custom


مؤشر البرايس اكشن هو
FIMarketStructure.dll

مؤشر الأوردر فلو هو 
FIOrderFlow.dll

أنقلهما جميعهاً أو أنقل أي واحد تريده منهما

بقية الملفات لابد من نقلها بالطبع


لإدخال الترخيص انظر الصورة رقم 2

أدخل الكود
JUBR-ANJU-BRNJ-UBRA 