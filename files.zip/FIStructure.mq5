//+------------------------------------------------------------------+
//|                                                  FIStructure.mq5 |
//|  Market-structure toolkit for MT5 (original implementation).    |
//|  BOS / CHoCH, swing labels, supply & demand, FVG, breakers,      |
//|  measured moves (fib), EMAs, SSL, squeeze, VWAP, session levels, |
//|  session boxes, multi-timeframe structure, alerts, EA buffers.   |
//+------------------------------------------------------------------+
#property copyright "Original implementation of generic market-structure concepts"
#property version   "1.00"
#property description "BOS/CHoCH, swings, S/D zones, FVG, breakers, measured moves,"
#property description "EMAs, SSL, squeeze, VWAP, session levels, MTF. Buffers readable by EAs."
#property indicator_chart_window
#property indicator_buffers 44
#property indicator_plots   7

#property indicator_label1  "SSL Open;SSL High;SSL Low;SSL Close"
#property indicator_type1   DRAW_COLOR_CANDLES
#property indicator_color1  C'38,166,154',C'239,83,80',clrGray
#property indicator_width1  1

#property indicator_label2  "EMA 1"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrDodgerBlue
#property indicator_width2  1

#property indicator_label3  "EMA 2"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrOrange
#property indicator_width3  1

#property indicator_label4  "EMA 3"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrSilver
#property indicator_width4  2

#property indicator_label5  "VWAP"
#property indicator_type5   DRAW_LINE
#property indicator_color5  clrMagenta
#property indicator_width5  2

#property indicator_label6  "SSL Up"
#property indicator_type6   DRAW_LINE
#property indicator_color6  clrLime
#property indicator_width6  1

#property indicator_label7  "SSL Down"
#property indicator_type7   DRAW_LINE
#property indicator_color7  clrRed
#property indicator_width7  1

//+------------------------------------------------------------------+
//| Buffer map (keep identical in FIStructure_EA.mq5)                |
//+------------------------------------------------------------------+
enum FI_BUF
  {
   B_CO=0, B_CH=1, B_CL=2, B_CC=3, B_CCLR=4,
   B_EMA1=5, B_EMA2=6, B_EMA3=7, B_VWAP=8, B_SSLU=9, B_SSLD=10,
   B_TREND=11,    // structure trend: +1 up / -1 down / 0 none
   B_BOS=12,      // +1 bullish BOS, -1 bearish BOS (on the bar that closed through the level)
   B_CHOCH=13,    // +1 bullish CHoCH, -1 bearish CHoCH
   B_SWH=14,      // swing-high type on confirmation bar: 1=HH 2=LH
   B_SWL=15,      // swing-low type on confirmation bar: 3=HL 4=LL
   B_LSH=16,      // latest confirmed swing-high price (0 = none)
   B_LSL=17,      // latest confirmed swing-low price  (0 = none)
   B_SQON=18,     // squeeze on (1/0)
   B_SQFIRE=19,   // squeeze fired: +1 / -1 (momentum sign), 0 none
   B_SQMOM=20,    // squeeze momentum value
   B_FVG=21,      // +1 new bullish FVG, -1 new bearish FVG
   B_ZTOUCH=22,   // +1 price entered demand/bull-breaker, -1 supply/bear-breaker
   B_MM=23,       // measured-move signal +1 / -1
   B_MMQ=24,      // measured-move quality 1..5
   B_MMT=25,      // measured-move target price
   B_MMS=26,      // measured-move stop (leg origin)
   B_PDH=27, B_PDL=28, B_YC=29, B_YO=30, B_DH=31, B_DL=32, B_DO=33,
   B_IBH=34, B_IBL=35, B_ORH=36, B_ORL=37,
   B_EMABIAS=38,  // +1 close>EMA2, -1 otherwise
   B_MTF=39,      // higher-timeframe structure trend (if MTF enabled)
   B_CUMPV=40, B_CUMV=41, B_SSLHLV=42, B_SQDELTA=43,
   B_COUNT=44
  };

enum ENUM_FI_LABELS { FI_LBL_LINES=0, FI_LBL_TEXT=1, FI_LBL_TEXT_TF=2 };

//+------------------------------------------------------------------+
//| Inputs                                                           |
//| NOTE: the first five inputs are the ones the EA passes through   |
//| iCustom(); keep their order if you edit this file.               |
//+------------------------------------------------------------------+
input int    InpSwingStrength = 5;      // Swing strength (bars each side)
input int    InpMaxBars       = 1500;   // Max history bars analysed
input double InpFVGMinATR     = 0.10;   // FVG minimum size (x ATR)
input double InpFibTolATR     = 0.10;   // Fib rejection tolerance (x ATR)
input int    InpMMMinQuality  = 2;      // Measured move minimum quality (1-5)

input group "=== Structure display ==="
input bool   InpShowSwings    = true;
input bool   InpShowBOS       = true;
input bool   InpShowCHoCH     = true;
input ENUM_FI_LABELS InpLabelMode = FI_LBL_TEXT;
input int    InpMaxSwingLabels= 30;
input int    InpMaxBreaks     = 25;
input int    InpExtendBars    = 25;     // Extend zones/levels to the right (bars)
input color  InpBullClr       = clrDodgerBlue;
input color  InpBearClr       = clrTomato;

input group "=== Supply / Demand / Breakers ==="
input bool   InpShowZones     = true;
input int    InpZoneCount     = 4;      // Max visible zones per side
input bool   InpZoneFill      = true;
input color  InpSupplyClr     = C'160,82,82';
input color  InpDemandClr     = C'70,140,110';
input bool   InpShowBreakers  = true;
input color  InpBullBrkClr    = clrTeal;
input color  InpBearBrkClr    = clrMaroon;

input group "=== Fair Value Gaps ==="
input bool   InpShowFVG       = true;
input int    InpFVGCount      = 10;
input color  InpBullFVGClr    = C'60,120,170';
input color  InpBearFVGClr    = C'170,110,60';

input group "=== Measured moves / Fib ==="
input bool   InpShowFib       = true;
input bool   InpShowMM        = true;
input color  InpFibClr        = clrGray;

input group "=== EMAs / SSL ==="
input bool   InpShowEMA       = true;
input int    InpEMA1          = 8;
input int    InpEMA2          = 21;
input int    InpEMA3          = 200;
input bool   InpShowSSL       = true;
input int    InpSSLPeriod     = 10;
input bool   InpSSLCandles    = false;  // Colour candles by SSL state
input color  InpSSLUpClr      = C'38,166,154';
input color  InpSSLDnClr      = C'239,83,80';

input group "=== Squeeze momentum ==="
input bool   InpShowSqueeze   = true;   // Mark squeeze fires on chart
input int    InpSqzLen        = 20;
input double InpBBMult        = 2.0;
input double InpKCMult        = 1.5;

input group "=== VWAP / daily levels ==="
input bool   InpShowVWAP      = true;
input int    InpDayStartHour  = 0;      // Server hour where a new "day" begins
input bool   InpShowPDHL      = true;
input bool   InpShowDayHL     = true;
input bool   InpShowYestOC    = true;
input bool   InpShowIB        = true;
input bool   InpShowOR        = true;
input int    InpIBMinutes     = 60;
input int    InpORMinutes     = 15;
input color  InpLvlPDClr      = clrGold;
input color  InpLvlDayClr     = clrSilver;
input color  InpLvlYClr       = clrKhaki;
input color  InpLvlIBClr      = clrOrchid;
input color  InpLvlORClr      = clrDeepSkyBlue;

input group "=== Sessions (broker SERVER time, HH:MM-HH:MM) ==="
input bool   InpShowSessions  = true;
input int    InpSessionDays   = 3;
input string InpAsia          = "01:00-09:00";
input string InpLondon        = "09:00-15:00";
input string InpNewYork       = "16:30-23:00";   // IB / OR start at New York start
input color  InpAsiaClr       = clrSlateBlue;
input color  InpLondonClr     = clrSeaGreen;
input color  InpNewYorkClr    = clrDarkOrange;

input group "=== Multi-timeframe structure ==="
input bool   InpUseMTF        = false;
input ENUM_TIMEFRAMES InpMTF  = PERIOD_H4;
input int    InpMTFBars       = 800;

input group "=== Alerts (evaluated on closed bars) ==="
input bool   InpAlertBOS      = false;
input bool   InpAlertCHoCH    = true;
input bool   InpAlertMM       = true;
input bool   InpAlertZone     = false;
input bool   InpAlertSqueeze  = false;
input bool   InpAlertFVG      = false;
input bool   InpAlertVWAP     = false;
input bool   InpAlertPopup    = true;
input bool   InpAlertPush     = false;
input bool   InpAlertEmail    = false;

//+------------------------------------------------------------------+
//| Data structures                                                  |
//+------------------------------------------------------------------+
#define SW_HH 1
#define SW_LH 2
#define SW_HL 3
#define SW_LL 4

struct FISwing { int idx; double price; int type; bool isHigh; };
struct FIBreak { int i0; int idx; double level; int dir; bool choch; };
struct FIZone
  {
   int      dir;          // +1 demand, -1 supply
   int      i0;           // pivot bar
   int      ic;           // confirmation bar
   double   top, bottom;
   bool     tested, broken;
   int      iBroken;
   bool     dead;
   int      iDead;
   bool     inside;
   datetime tConfirm, tBroken;
  };
struct FIFvg   { int dir; int i0; int ic; double top; double bottom; bool filled; int iFilled; };
struct FIMM    { int idx; int dir; double level; double ratio; double target; double stop; int quality; };

//+------------------------------------------------------------------+
//| Structure engine - incremental, one closed bar at a time         |
//+------------------------------------------------------------------+
class CFIEngine
  {
public:
   int        m_S;
   double     m_fvgMinATR;
   double     m_fibTolATR;
   int        m_mmMinQ;
   int        m_psec;
   int        m_off;          // chart-bar index of engine bar 0
   CFIEngine *m_htf;

   int        m_n;
   datetime   m_t[];
   double     m_o[], m_h[], m_l[], m_c[], m_atr[];
   double     o_trend[], o_bos[], o_choch[], o_swh[], o_swl[], o_lsh[], o_lsl[];
   double     o_fvg[], o_fvgf[], o_touch[], o_mm[], o_mmq[], o_mmt[], o_mms[];

   FISwing    m_sw[];   int m_nsw;
   FIBreak    m_br[];   int m_nbr;
   FIZone     m_zn[];   int m_nzn;
   FIFvg      m_fv[];   int m_nfv;
   FIMM       m_mm[];   int m_nmm;
   int        m_lz[];   int m_nlz;   // live zone indices
   int        m_lf[];   int m_nlf;   // live (unfilled) FVG indices

   int        m_trend;
   bool       m_havePH, m_havePL;
   int        m_phIdx, m_plIdx;
   double     m_phPx, m_plPx;
   double     m_shLevel, m_slLevel;
   int        m_shIdx, m_slIdx;
   bool       m_shBroken, m_slBroken;
   bool       m_mmFired;

   CFIEngine()
     {
      m_S=5; m_fvgMinATR=0.1; m_fibTolATR=0.1; m_mmMinQ=2; m_psec=60; m_off=0; m_htf=NULL;
      Reset();
     }

   void Config(const int strength,const double fvgMin,const double fibTol,const int mmMinQ,const int psec)
     {
      m_S=MathMax(1,strength); m_fvgMinATR=fvgMin; m_fibTolATR=fibTol; m_mmMinQ=mmMinQ; m_psec=psec;
     }

   void Reset()
     {
      m_n=0;
      ArrayResize(m_t,0); ArrayResize(m_o,0); ArrayResize(m_h,0); ArrayResize(m_l,0); ArrayResize(m_c,0); ArrayResize(m_atr,0);
      ArrayResize(o_trend,0); ArrayResize(o_bos,0); ArrayResize(o_choch,0); ArrayResize(o_swh,0); ArrayResize(o_swl,0);
      ArrayResize(o_lsh,0); ArrayResize(o_lsl,0); ArrayResize(o_fvg,0); ArrayResize(o_fvgf,0); ArrayResize(o_touch,0);
      ArrayResize(o_mm,0); ArrayResize(o_mmq,0); ArrayResize(o_mmt,0); ArrayResize(o_mms,0);
      ArrayResize(m_sw,0); m_nsw=0;
      ArrayResize(m_br,0); m_nbr=0;
      ArrayResize(m_zn,0); m_nzn=0;
      ArrayResize(m_fv,0); m_nfv=0;
      ArrayResize(m_mm,0); m_nmm=0;
      ArrayResize(m_lz,0); m_nlz=0;
      ArrayResize(m_lf,0); m_nlf=0;
      m_trend=0; m_havePH=false; m_havePL=false; m_phIdx=-1; m_plIdx=-1; m_phPx=0; m_plPx=0;
      m_shLevel=0; m_slLevel=0; m_shIdx=-1; m_slIdx=-1; m_shBroken=true; m_slBroken=true; m_mmFired=false;
     }

   datetime LastTime() const { return (m_n>0) ? m_t[m_n-1] : 0; }

   void Grow(double &a[]) { ArrayResize(a,m_n,8192); a[m_n-1]=0.0; }

   void Append(const datetime t,const double o,const double h,const double l,const double c)
     {
      m_n++;
      int i=m_n-1;
      ArrayResize(m_t,m_n,8192);
      Grow(m_o); Grow(m_h); Grow(m_l); Grow(m_c); Grow(m_atr);
      Grow(o_trend); Grow(o_bos); Grow(o_choch); Grow(o_swh); Grow(o_swl); Grow(o_lsh); Grow(o_lsl);
      Grow(o_fvg); Grow(o_fvgf); Grow(o_touch); Grow(o_mm); Grow(o_mmq); Grow(o_mmt); Grow(o_mms);
      m_t[i]=t; m_o[i]=o; m_h[i]=h; m_l[i]=l; m_c[i]=c;
      Step(i);
     }

   //--- list helpers
   void AddSwing(const int idx,const double price,const int type,const bool isHigh)
     {
      ArrayResize(m_sw,m_nsw+1,512);
      m_sw[m_nsw].idx=idx; m_sw[m_nsw].price=price; m_sw[m_nsw].type=type; m_sw[m_nsw].isHigh=isHigh;
      m_nsw++;
     }

   void AddBreak(const int i0,const int idx,const double level,const int dir,const bool choch)
     {
      ArrayResize(m_br,m_nbr+1,512);
      m_br[m_nbr].i0=i0; m_br[m_nbr].idx=idx; m_br[m_nbr].level=level; m_br[m_nbr].dir=dir; m_br[m_nbr].choch=choch;
      m_nbr++;
     }

   void AddZone(const int dir,const int k,const int i)
     {
      FIZone z;
      double minH=0.1*m_atr[i];
      z.dir=dir; z.i0=k; z.ic=i;
      if(dir<0)
        {
         z.top=m_h[k]; z.bottom=MathMax(m_o[k],m_c[k]);
         if(z.top-z.bottom<minH) z.bottom=z.top-minH;
        }
      else
        {
         z.bottom=m_l[k]; z.top=MathMin(m_o[k],m_c[k]);
         if(z.top-z.bottom<minH) z.top=z.bottom+minH;
        }
      z.tested=false; z.broken=false; z.iBroken=-1; z.dead=false; z.iDead=-1; z.inside=false;
      z.tConfirm=m_t[i]+m_psec; z.tBroken=0;
      ArrayResize(m_zn,m_nzn+1,512);
      m_zn[m_nzn]=z;
      ArrayResize(m_lz,m_nlz+1,512);
      m_lz[m_nlz]=m_nzn;
      m_nlz++;
      m_nzn++;
     }

   void AddFvg(const int dir,const int i0,const int ic,const double top,const double bottom)
     {
      ArrayResize(m_fv,m_nfv+1,512);
      m_fv[m_nfv].dir=dir; m_fv[m_nfv].i0=i0; m_fv[m_nfv].ic=ic; m_fv[m_nfv].top=top; m_fv[m_nfv].bottom=bottom;
      m_fv[m_nfv].filled=false; m_fv[m_nfv].iFilled=-1;
      ArrayResize(m_lf,m_nlf+1,512);
      m_lf[m_nlf]=m_nfv;
      m_nlf++;
      m_nfv++;
     }

   //--- queries
   bool FvgNear(const int dir,const int i,const double price,const double tol)
     {
      for(int q=0;q<m_nlf;q++)
        {
         int f=m_lf[q];
         if(m_fv[f].dir!=dir || m_fv[f].ic>=i) continue;
         if(price>=m_fv[f].bottom-tol && price<=m_fv[f].top+tol) return true;
        }
      return false;
     }

   bool ZoneNear(const int dir,const int i,const double price,const double tol)
     {
      for(int q=0;q<m_nlz;q++)
        {
         int z=m_lz[q];
         if(m_zn[z].dir!=dir || m_zn[z].broken || m_zn[z].ic>=i) continue;
         if(price>=m_zn[z].bottom-tol && price<=m_zn[z].top+tol) return true;
        }
      return false;
     }

   // zone of this engine's timeframe that was known and unbroken at time 'at'
   bool HasZone(const int dir,const datetime at,const double price,const double tol)
     {
      for(int z=0;z<m_nzn;z++)
        {
         if(m_zn[z].dir!=dir) continue;
         if(m_zn[z].tConfirm>at) continue;
         if(m_zn[z].broken && m_zn[z].tBroken<=at) continue;
         if(price>=m_zn[z].bottom-tol && price<=m_zn[z].top+tol) return true;
        }
      return false;
     }

   //--- pivots
   void OnPivotHigh(const int k,const int i)
     {
      int type=(!m_havePH || m_h[k]>m_phPx) ? SW_HH : SW_LH;
      AddSwing(k,m_h[k],type,true);
      m_havePH=true; m_phIdx=k; m_phPx=m_h[k];
      m_shLevel=m_h[k]; m_shIdx=k; m_shBroken=false;
      o_swh[i]=type;
      AddZone(-1,k,i);
      m_mmFired=false;
     }

   void OnPivotLow(const int k,const int i)
     {
      int type=(!m_havePL || m_l[k]>m_plPx) ? SW_HL : SW_LL;
      AddSwing(k,m_l[k],type,false);
      m_havePL=true; m_plIdx=k; m_plPx=m_l[k];
      m_slLevel=m_l[k]; m_slIdx=k; m_slBroken=false;
      o_swl[i]=type;
      AddZone(1,k,i);
      m_mmFired=false;
     }

   //--- zones
   void UpdateZones(const int i)
     {
      for(int q=0;q<m_nlz;q++)
        {
         int zi=m_lz[q];
         if(m_zn[zi].ic>=i) continue;
         int dir=m_zn[zi].dir;
         double top=m_zn[zi].top, bot=m_zn[zi].bottom;
         if(!m_zn[zi].broken)
           {
            bool br=(dir>0) ? (m_c[i]<bot) : (m_c[i]>top);
            if(br)
              {
               m_zn[zi].broken=true; m_zn[zi].iBroken=i; m_zn[zi].tBroken=m_t[i]+m_psec;
               m_zn[zi].inside=false;
              }
            else
              {
               bool ins=(dir>0) ? (m_l[i]<=top) : (m_h[i]>=bot);
               if(ins)
                 {
                  m_zn[zi].tested=true;
                  if(!m_zn[zi].inside) o_touch[i]=dir;
                 }
               m_zn[zi].inside=ins;
              }
           }
         else
           {
            // broken demand = bearish breaker (resistance); broken supply = bullish breaker (support)
            bool dead=(dir>0) ? (m_c[i]>top) : (m_c[i]<bot);
            if(dead)
              {
               m_zn[zi].dead=true; m_zn[zi].iDead=i;
               m_lz[q]=m_lz[m_nlz-1]; m_nlz--; q--;
              }
            else
              {
               bool ins=(m_h[i]>=bot && m_l[i]<=top);
               if(ins && !m_zn[zi].inside) o_touch[i]=(dir>0) ? -1.0 : 1.0;
               m_zn[zi].inside=ins;
              }
           }
        }
     }

   //--- FVG
   void UpdateFvgs(const int i)
     {
      for(int q=0;q<m_nlf;q++)
        {
         int f=m_lf[q];
         if(m_fv[f].ic>=i) continue;
         bool fill=(m_fv[f].dir>0) ? (m_l[i]<=m_fv[f].bottom) : (m_h[i]>=m_fv[f].top);
         if(fill)
           {
            m_fv[f].filled=true; m_fv[f].iFilled=i;
            o_fvgf[i]+=1.0;
            m_lf[q]=m_lf[m_nlf-1]; m_nlf--; q--;
           }
        }
      if(i>=2)
        {
         double minGap=m_fvgMinATR*m_atr[i];
         if(m_l[i]>m_h[i-2] && (m_l[i]-m_h[i-2])>=minGap)
           {
            AddFvg(1,i-2,i,m_l[i],m_h[i-2]);
            o_fvg[i]=1.0;
           }
         else if(m_h[i]<m_l[i-2] && (m_l[i-2]-m_h[i])>=minGap)
           {
            AddFvg(-1,i-2,i,m_l[i-2],m_h[i]);
            o_fvg[i]=-1.0;
           }
        }
     }

   //--- measured move: rejection at 61.8 / 50 of the active swing range
   void CheckMM(const int i)
     {
      if(!m_havePH || !m_havePL || m_mmFired) return;
      double range=m_phPx-m_plPx;
      if(range<=0.0) return;
      double tol=m_fibTolATR*m_atr[i];
      bool up=(m_phIdx>m_plIdx);             // low -> high leg, look for buy rejection
      double body=MathAbs(m_c[i]-m_o[i]);
      double rng=m_h[i]-m_l[i];
      double ratios[2];
      ratios[0]=0.618; ratios[1]=0.5;
      for(int r=0;r<2;r++)
        {
         double L=up ? (m_phPx-ratios[r]*range) : (m_plPx+ratios[r]*range);
         bool sig=false;
         if(up) sig=(m_l[i]<=L+tol && m_c[i]>L && m_c[i]>m_o[i] && m_c[i]<m_phPx && m_c[i]>m_plPx);
         else   sig=(m_h[i]>=L-tol && m_c[i]<L && m_c[i]<m_o[i] && m_c[i]>m_plPx && m_c[i]<m_phPx);
         if(!sig) continue;
         int dir=up ? 1 : -1;
         int q=1;
         if(FvgNear(dir,i,L,tol)) q++;
         if(ZoneNear(dir,i,L,tol)) q++;
         if(rng>0.0 && body/rng>=0.6) q++;
         if(m_htf!=NULL && CheckPointer(m_htf)!=POINTER_INVALID)
            if(m_htf.HasZone(dir,m_t[i]+m_psec,L,tol)) q++;
         if(q<m_mmMinQ) continue;
         double target=up ? (m_phPx+0.236*range) : (m_plPx-0.236*range);
         double stop=up ? m_plPx : m_phPx;
         o_mm[i]=dir; o_mmq[i]=q; o_mmt[i]=target; o_mms[i]=stop;
         ArrayResize(m_mm,m_nmm+1,128);
         m_mm[m_nmm].idx=i; m_mm[m_nmm].dir=dir; m_mm[m_nmm].level=L; m_mm[m_nmm].ratio=ratios[r];
         m_mm[m_nmm].target=target; m_mm[m_nmm].stop=stop; m_mm[m_nmm].quality=q;
         m_nmm++;
         m_mmFired=true;
         break;
        }
     }

   //--- one closed bar
   void Step(const int i)
     {
      double tr=m_h[i]-m_l[i];
      if(i>0) tr=MathMax(tr,MathMax(MathAbs(m_h[i]-m_c[i-1]),MathAbs(m_l[i]-m_c[i-1])));
      if(i==0) m_atr[i]=tr;
      else if(i<14) m_atr[i]=(m_atr[i-1]*i+tr)/(i+1.0);
      else m_atr[i]=(m_atr[i-1]*13.0+tr)/14.0;

      int k=i-m_S;
      if(k>=m_S)
        {
         bool isH=true, isL=true;
         for(int j=k-m_S;j<=k+m_S && (isH||isL);j++)
           {
            if(j==k) continue;
            if(j<k)
              {
               if(m_h[j]>=m_h[k]) isH=false;
               if(m_l[j]<=m_l[k]) isL=false;
              }
            else
              {
               if(m_h[j]>m_h[k]) isH=false;
               if(m_l[j]<m_l[k]) isL=false;
              }
           }
         if(isH) OnPivotHigh(k,i);
         if(isL) OnPivotLow(k,i);
        }

      UpdateZones(i);
      UpdateFvgs(i);

      if(m_havePH && !m_shBroken && m_c[i]>m_shLevel)
        {
         bool ch=(m_trend<0);
         AddBreak(m_shIdx,i,m_shLevel,1,ch);
         m_trend=1; m_shBroken=true;
         if(ch) o_choch[i]=1.0; else o_bos[i]=1.0;
        }
      else if(m_havePL && !m_slBroken && m_c[i]<m_slLevel)
        {
         bool ch=(m_trend>0);
         AddBreak(m_slIdx,i,m_slLevel,-1,ch);
         m_trend=-1; m_slBroken=true;
         if(ch) o_choch[i]=-1.0; else o_bos[i]=-1.0;
        }

      o_trend[i]=m_trend;
      o_lsh[i]=m_havePH ? m_phPx : 0.0;
      o_lsl[i]=m_havePL ? m_plPx : 0.0;

      CheckMM(i);
     }
  };

//+------------------------------------------------------------------+
//| Globals                                                          |
//+------------------------------------------------------------------+
double bCO[],bCH[],bCL[],bCC[],bCCLR[];
double bEMA1[],bEMA2[],bEMA3[],bVWAP[],bSSLU[],bSSLD[];
double bTrend[],bBOS[],bCHOCH[],bSWH[],bSWL[],bLSH[],bLSL[];
double bSqOn[],bSqF[],bSqM[],bFVG[],bZT[],bMM[],bMMQ[],bMMT[],bMMS[];
double bPDH[],bPDL[],bYC[],bYO[],bDH[],bDL[],bDO[],bIBH[],bIBL[],bORH[],bORL[];
double bBias[],bMTF[],bCumPV[],bCumV[],bHLV[],bSqD[];

CFIEngine g_eng;
CFIEngine g_mtf;

string   g_pfx="FIS_";
int      g_ps=60;
int      g_psM=0;
bool     g_useMTF=false;
bool     g_draw=true;
datetime g_lastBar=0;
datetime g_alertBar=0;
int      g_nextChart=0;
int      g_copied=0;
double   g_a1=0,g_a2=0,g_a3=0;
int      g_ss[3],g_se[3];
int      g_nyStart=990;

//+------------------------------------------------------------------+
//| Small helpers                                                    |
//+------------------------------------------------------------------+
string TfName(const ENUM_TIMEFRAMES tf)
  {
   string s=EnumToString(tf);
   return StringSubstr(s,7);
  }

bool ParseHM(const string s,int &mins)
  {
   int p=StringFind(s,":");
   if(p<0) return false;
   int h=(int)StringToInteger(StringSubstr(s,0,p));
   int m=(int)StringToInteger(StringSubstr(s,p+1));
   if(h<0 || h>24 || m<0 || m>59) return false;
   mins=h*60+m;
   return true;
  }

bool ParseRange(string s,int &a,int &b)
  {
   StringReplace(s," ","");
   int p=StringFind(s,"-");
   if(p<0) return false;
   int x=0,y=0;
   if(!ParseHM(StringSubstr(s,0,p),x)) return false;
   if(!ParseHM(StringSubstr(s,p+1),y)) return false;
   a=x; b=y;
   return true;
  }

bool InSession(const int m,const int s)
  {
   if(g_ss[s]<g_se[s]) return (m>=g_ss[s] && m<g_se[s]);
   return (m>=g_ss[s] || m<g_se[s]);
  }

void Notify(const string msg)
  {
   if(InpAlertPopup) Alert(msg);
   if(InpAlertPush)  SendNotification(msg);
   if(InpAlertEmail) SendMail("FIStructure",msg);
  }

//--- object helpers
void ObjCommon(const string name)
  {
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void ObjLine(const string name,const datetime t1,const double p1,const datetime t2,const double p2,
             const color clr,const ENUM_LINE_STYLE st,const int w)
  {
   if(!ObjectCreate(0,name,OBJ_TREND,0,t1,p1,t2,p2)) return;
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_STYLE,st);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,w);
   ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);
   ObjCommon(name);
  }

void ObjText(const string name,const datetime t,const double p,const string txt,const color clr,
             const int size,const ENUM_ANCHOR_POINT anchor)
  {
   if(!ObjectCreate(0,name,OBJ_TEXT,0,t,p)) return;
   ObjectSetString(0,name,OBJPROP_TEXT,txt);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,size);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,anchor);
   ObjCommon(name);
  }

void ObjRect(const string name,const datetime t1,const double p1,const datetime t2,const double p2,
             const color clr,const bool fill)
  {
   if(!ObjectCreate(0,name,OBJ_RECTANGLE,0,t1,p1,t2,p2)) return;
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_FILL,fill);
   ObjectSetInteger(0,name,OBJPROP_BACK,true);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
   ObjCommon(name);
  }

void ObjArrow(const string name,const datetime t,const double p,const int code,const color clr,
              const ENUM_ARROW_ANCHOR anchor)
  {
   if(!ObjectCreate(0,name,OBJ_ARROW,0,t,p)) return;
   ObjectSetInteger(0,name,OBJPROP_ARROWCODE,code);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,anchor);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
   ObjCommon(name);
  }

//+------------------------------------------------------------------+
//| Init / deinit                                                    |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSwingStrength<1 || InpSqzLen<4 || InpSSLPeriod<2)
     {
      Print("FIStructure: invalid input (swing strength >=1, squeeze length >=4, SSL period >=2).");
      return INIT_PARAMETERS_INCORRECT;
     }

   SetIndexBuffer(B_CO,bCO,INDICATOR_DATA);
   SetIndexBuffer(B_CH,bCH,INDICATOR_DATA);
   SetIndexBuffer(B_CL,bCL,INDICATOR_DATA);
   SetIndexBuffer(B_CC,bCC,INDICATOR_DATA);
   SetIndexBuffer(B_CCLR,bCCLR,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(B_EMA1,bEMA1,INDICATOR_DATA);
   SetIndexBuffer(B_EMA2,bEMA2,INDICATOR_DATA);
   SetIndexBuffer(B_EMA3,bEMA3,INDICATOR_DATA);
   SetIndexBuffer(B_VWAP,bVWAP,INDICATOR_DATA);
   SetIndexBuffer(B_SSLU,bSSLU,INDICATOR_DATA);
   SetIndexBuffer(B_SSLD,bSSLD,INDICATOR_DATA);
   SetIndexBuffer(B_TREND,bTrend,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_BOS,bBOS,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_CHOCH,bCHOCH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SWH,bSWH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SWL,bSWL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_LSH,bLSH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_LSL,bLSL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SQON,bSqOn,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SQFIRE,bSqF,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SQMOM,bSqM,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_FVG,bFVG,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_ZTOUCH,bZT,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_MM,bMM,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_MMQ,bMMQ,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_MMT,bMMT,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_MMS,bMMS,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_PDH,bPDH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_PDL,bPDL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_YC,bYC,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_YO,bYO,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_DH,bDH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_DL,bDL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_DO,bDO,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_IBH,bIBH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_IBL,bIBL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_ORH,bORH,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_ORL,bORL,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_EMABIAS,bBias,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_MTF,bMTF,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_CUMPV,bCumPV,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_CUMV,bCumV,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SSLHLV,bHLV,INDICATOR_CALCULATIONS);
   SetIndexBuffer(B_SQDELTA,bSqD,INDICATOR_CALCULATIONS);

   // plot appearance
   PlotIndexSetInteger(0,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,0,InpSSLUpClr);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,1,InpSSLDnClr);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,2,clrGray);
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,InpSSLCandles ? DRAW_COLOR_CANDLES : DRAW_NONE);
   for(int p=1;p<=6;p++) PlotIndexSetDouble(p,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   PlotIndexSetInteger(1,PLOT_DRAW_TYPE,InpShowEMA ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(2,PLOT_DRAW_TYPE,InpShowEMA ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(3,PLOT_DRAW_TYPE,InpShowEMA ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(4,PLOT_DRAW_TYPE,InpShowVWAP ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(5,PLOT_DRAW_TYPE,InpShowSSL ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(6,PLOT_DRAW_TYPE,InpShowSSL ? DRAW_LINE : DRAW_NONE);
   PlotIndexSetInteger(5,PLOT_LINE_COLOR,InpSSLUpClr);
   PlotIndexSetInteger(6,PLOT_LINE_COLOR,InpSSLDnClr);

   g_a1=2.0/(MathMax(1,InpEMA1)+1.0);
   g_a2=2.0/(MathMax(1,InpEMA2)+1.0);
   g_a3=2.0/(MathMax(1,InpEMA3)+1.0);

   g_ps=PeriodSeconds();
   g_useMTF=false;
   g_psM=0;
   if(InpUseMTF)
     {
      if(PeriodSeconds(InpMTF)>g_ps)
        {
         g_useMTF=true;
         g_psM=PeriodSeconds(InpMTF);
        }
      else Print("FIStructure: MTF timeframe must be higher than the chart timeframe - MTF disabled.");
     }

   g_ss[0]=60;  g_se[0]=540;
   g_ss[1]=540; g_se[1]=900;
   g_ss[2]=990; g_se[2]=1380;
   if(!ParseRange(InpAsia,g_ss[0],g_se[0]))     Print("FIStructure: bad Asia range, using default.");
   if(!ParseRange(InpLondon,g_ss[1],g_se[1]))   Print("FIStructure: bad London range, using default.");
   if(!ParseRange(InpNewYork,g_ss[2],g_se[2]))  Print("FIStructure: bad New York range, using default.");
   g_nyStart=g_ss[2];

   g_eng.Config(InpSwingStrength,InpFVGMinATR,InpFibTolATR,InpMMMinQuality,g_ps);
   g_eng.m_htf=NULL;
   if(g_useMTF)
     {
      g_mtf.Config(InpSwingStrength,InpFVGMinATR,InpFibTolATR,InpMMMinQuality,g_psM);
      g_eng.m_htf=GetPointer(g_mtf);
     }
   g_mtf.Reset();
   g_eng.Reset();

   g_draw=!(MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_VISUAL_MODE));
   g_lastBar=0; g_alertBar=0; g_nextChart=0; g_copied=0;

   IndicatorSetString(INDICATOR_SHORTNAME,"FIStructure");
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0,g_pfx);
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Per-tick incremental calculations                                |
//+------------------------------------------------------------------+
void CalcBasic(const int start,const int n,const datetime &time[],const double &open[],const double &high[],
               const double &low[],const double &close[],const long &tick_volume[])
  {
   const int L=InpSqzLen;
   const int P=InpSSLPeriod;
   for(int i=start;i<n;i++)
     {
      //--- EMAs
      if(i==0)
        {
         bEMA1[i]=close[i]; bEMA2[i]=close[i]; bEMA3[i]=close[i];
        }
      else
        {
         bEMA1[i]=g_a1*close[i]+(1.0-g_a1)*bEMA1[i-1];
         bEMA2[i]=g_a2*close[i]+(1.0-g_a2)*bEMA2[i-1];
         bEMA3[i]=g_a3*close[i]+(1.0-g_a3)*bEMA3[i-1];
        }
      bBias[i]=(close[i]>bEMA2[i]) ? 1.0 : -1.0;

      //--- day / VWAP / levels
      long key=((long)time[i]-(long)InpDayStartHour*3600)/86400;
      long pkey=(i>0) ? (((long)time[i-1]-(long)InpDayStartHour*3600)/86400) : -1;
      bool newDay=(i==0 || key!=pkey);
      double typ=(high[i]+low[i]+close[i])/3.0;
      double vol=MathMax(1.0,(double)tick_volume[i]);
      if(newDay)
        {
         bCumPV[i]=typ*vol; bCumV[i]=vol;
         if(i>0)
           {
            bPDH[i]=bDH[i-1]; bPDL[i]=bDL[i-1]; bYC[i]=close[i-1]; bYO[i]=bDO[i-1];
           }
         else
           {
            bPDH[i]=0.0; bPDL[i]=0.0; bYC[i]=0.0; bYO[i]=0.0;
           }
         bDH[i]=high[i]; bDL[i]=low[i]; bDO[i]=open[i];
         bIBH[i]=0.0; bIBL[i]=0.0; bORH[i]=0.0; bORL[i]=0.0;
        }
      else
        {
         bCumPV[i]=bCumPV[i-1]+typ*vol; bCumV[i]=bCumV[i-1]+vol;
         bPDH[i]=bPDH[i-1]; bPDL[i]=bPDL[i-1]; bYC[i]=bYC[i-1]; bYO[i]=bYO[i-1];
         bDH[i]=MathMax(bDH[i-1],high[i]); bDL[i]=MathMin(bDL[i-1],low[i]); bDO[i]=bDO[i-1];
         bIBH[i]=bIBH[i-1]; bIBL[i]=bIBL[i-1]; bORH[i]=bORH[i-1]; bORL[i]=bORL[i-1];
        }
      bVWAP[i]=bCumPV[i]/bCumV[i];

      int m=(int)(((long)time[i]%86400)/60);
      if(m>=g_nyStart && m<g_nyStart+InpIBMinutes)
        {
         if(bIBH[i]==0.0) { bIBH[i]=high[i]; bIBL[i]=low[i]; }
         else { bIBH[i]=MathMax(bIBH[i],high[i]); bIBL[i]=MathMin(bIBL[i],low[i]); }
        }
      if(m>=g_nyStart && m<g_nyStart+InpORMinutes)
        {
         if(bORH[i]==0.0) { bORH[i]=high[i]; bORL[i]=low[i]; }
         else { bORH[i]=MathMax(bORH[i],high[i]); bORL[i]=MathMin(bORL[i],low[i]); }
        }

      //--- SSL channel
      double hlv=0.0;
      if(i>=P-1)
        {
         double sh=0.0, sl=0.0;
         for(int j=0;j<P;j++) { sh+=high[i-j]; sl+=low[i-j]; }
         sh/=P; sl/=P;
         if(close[i]>sh) hlv=1.0;
         else if(close[i]<sl) hlv=-1.0;
         else hlv=(i>0) ? bHLV[i-1] : 0.0;
         if(hlv<0.0) { bSSLU[i]=sl; bSSLD[i]=sh; }
         else        { bSSLU[i]=sh; bSSLD[i]=sl; }
        }
      else
        {
         bSSLU[i]=EMPTY_VALUE; bSSLD[i]=EMPTY_VALUE;
        }
      bHLV[i]=hlv;
      bCO[i]=open[i]; bCH[i]=high[i]; bCL[i]=low[i]; bCC[i]=close[i];
      bCCLR[i]=(hlv>0.0) ? 0.0 : ((hlv<0.0) ? 1.0 : 2.0);

      //--- squeeze momentum
      if(i>=L-1)
        {
         double sma=0.0;
         for(int j=0;j<L;j++) sma+=close[i-j];
         sma/=L;
         double var=0.0;
         for(int j=0;j<L;j++) { double d=close[i-j]-sma; var+=d*d; }
         double sd=MathSqrt(var/L);
         double rma=0.0, hh=-DBL_MAX, ll=DBL_MAX;
         for(int j=0;j<L;j++)
           {
            int k=i-j;
            double tr=high[k]-low[k];
            if(k>0) tr=MathMax(tr,MathMax(MathAbs(high[k]-close[k-1]),MathAbs(low[k]-close[k-1])));
            rma+=tr;
            hh=MathMax(hh,high[k]);
            ll=MathMin(ll,low[k]);
           }
         rma/=L;
         double bbU=sma+InpBBMult*sd, bbL=sma-InpBBMult*sd;
         double kcU=sma+InpKCMult*rma, kcL=sma-InpKCMult*rma;
         bool on=(bbL>kcL && bbU<kcU);
         bSqOn[i]=on ? 1.0 : 0.0;
         bSqD[i]=close[i]-((hh+ll)/2.0+sma)/2.0;
         double mom=0.0;
         if(i>=2*L-2)
           {
            double sx=0.0,sy=0.0,sxy=0.0,sxx=0.0;
            for(int j=0;j<L;j++)
              {
               double y=bSqD[i-L+1+j];
               sx+=j; sy+=y; sxy+=j*y; sxx+=(double)j*j;
              }
            double den=L*sxx-sx*sx;
            double slope=(den!=0.0) ? (L*sxy-sx*sy)/den : 0.0;
            double icpt=(sy-slope*sx)/L;
            mom=icpt+slope*(L-1);
           }
         bSqM[i]=mom;
         bool prevOn=(i>0 && bSqOn[i-1]>0.5);
         bSqF[i]=(prevOn && !on) ? ((mom>=0.0) ? 1.0 : -1.0) : 0.0;
        }
      else
        {
         bSqOn[i]=0.0; bSqD[i]=0.0; bSqM[i]=0.0; bSqF[i]=0.0;
        }
     }
  }

//+------------------------------------------------------------------+
//| Engine <-> buffers                                               |
//+------------------------------------------------------------------+
void ZeroStructureBuffers(const int i)
  {
   bTrend[i]=0.0; bBOS[i]=0.0; bCHOCH[i]=0.0; bSWH[i]=0.0; bSWL[i]=0.0; bLSH[i]=0.0; bLSL[i]=0.0;
   bFVG[i]=0.0; bZT[i]=0.0; bMM[i]=0.0; bMMQ[i]=0.0; bMMT[i]=0.0; bMMS[i]=0.0; bMTF[i]=0.0;
  }

// returns true when the MTF engine was (re)loaded from scratch
bool SyncMTF()
  {
   if(!g_useMTF) return false;
   datetime lastClosed=iTime(_Symbol,InpMTF,1);
   if(lastClosed==0) return false;
   if(g_mtf.m_n>0 && g_mtf.LastTime()>=lastClosed) return false;

   bool reloaded=false;
   int want=50;
   if(g_mtf.m_n==0)
     {
      want=MathMin(InpMTFBars,Bars(_Symbol,InpMTF)-1);
      reloaded=true;
     }
   if(want<=0) return false;
   MqlRates r[];
   ArraySetAsSeries(r,false);
   int got=CopyRates(_Symbol,InpMTF,1,want,r);
   if(got<=0) return false;
   if(g_mtf.m_n>0 && r[0].time>g_mtf.LastTime())
     {
      // gap: more new bars than we copied -> reload everything
      g_mtf.Reset();
      want=MathMin(InpMTFBars,Bars(_Symbol,InpMTF)-1);
      got=CopyRates(_Symbol,InpMTF,1,want,r);
      if(got<=0) return false;
      reloaded=true;
     }
   for(int k=0;k<got;k++)
      if(g_mtf.m_n==0 || r[k].time>g_mtf.LastTime())
         g_mtf.Append(r[k].time,r[k].open,r[k].high,r[k].low,r[k].close);
   return reloaded;
  }

void BackfillMTF(const int n,const datetime &t[])
  {
   int j=0;
   int m=g_mtf.m_n;
   for(int i=0;i<n;i++)
     {
      if(m<=0) { bMTF[i]=0.0; continue; }
      while(j+1<m && g_mtf.m_t[j+1]+g_psM<=t[i]) j++;
      if(g_mtf.m_t[j]+g_psM<=t[i]) bMTF[i]=g_mtf.o_trend[j];
      else bMTF[i]=0.0;
     }
  }

//+------------------------------------------------------------------+
//| Drawing                                                          |
//+------------------------------------------------------------------+
void DrawEngine(CFIEngine &e,const string tag,const bool mtf,const datetime tRight)
  {
   if(e.m_n<2) return;
   string pf=g_pfx+(mtf ? "M" : "C")+"_";
   int fs=mtf ? 9 : 8;

   //--- swing labels
   if(InpShowSwings)
     {
      int cnt=0;
      for(int s=e.m_nsw-1;s>=0 && cnt<InpMaxSwingLabels;s--,cnt++)
        {
         string txt="";
         switch(e.m_sw[s].type)
           {
            case SW_HH: txt="HH"; break;
            case SW_LH: txt="LH"; break;
            case SW_HL: txt="HL"; break;
            default:    txt="LL"; break;
           }
         if(mtf) txt+=" "+tag;
         bool bull=(e.m_sw[s].type==SW_HH || e.m_sw[s].type==SW_HL);
         ObjText(pf+"SW"+IntegerToString(s),e.m_t[e.m_sw[s].idx],e.m_sw[s].price,txt,
                 bull ? InpBullClr : InpBearClr,fs,e.m_sw[s].isHigh ? ANCHOR_LOWER : ANCHOR_UPPER);
        }
     }

   //--- BOS / CHoCH
   int shown=0;
   for(int b=e.m_nbr-1;b>=0 && shown<InpMaxBreaks;b--)
     {
      bool ch=e.m_br[b].choch;
      if(ch && !InpShowCHoCH) continue;
      if(!ch && !InpShowBOS) continue;
      shown++;
      color clr=(e.m_br[b].dir>0) ? InpBullClr : InpBearClr;
      datetime t1=e.m_t[e.m_br[b].i0];
      datetime t2=e.m_t[e.m_br[b].idx];
      double lv=e.m_br[b].level;
      ObjLine(pf+"BR"+IntegerToString(b),t1,lv,t2,lv,clr,ch ? STYLE_DASH : STYLE_SOLID,mtf ? 2 : 1);
      if(InpLabelMode!=FI_LBL_LINES)
        {
         string txt=ch ? "CHoCH" : "BOS";
         if(InpLabelMode==FI_LBL_TEXT_TF) txt+=" "+tag;
         datetime tm=(datetime)(((long)t1+(long)t2)/2);
         ObjText(pf+"BT"+IntegerToString(b),tm,lv,txt,clr,fs,(e.m_br[b].dir>0) ? ANCHOR_LOWER : ANCHOR_UPPER);
        }
     }

   //--- zones + breakers
   if(InpShowZones)
     {
      int cS=0,cD=0,cBB=0,cBR=0;
      for(int z=e.m_nzn-1;z>=0;z--)
        {
         if(e.m_zn[z].dead) continue;
         int dir=e.m_zn[z].dir;
         if(!e.m_zn[z].broken)
           {
            if(dir<0) { if(cS>=InpZoneCount) continue; cS++; }
            else      { if(cD>=InpZoneCount) continue; cD++; }
            color zc=(dir<0) ? InpSupplyClr : InpDemandClr;
            ObjRect(pf+"Z"+IntegerToString(z),e.m_t[e.m_zn[z].i0],e.m_zn[z].top,tRight,e.m_zn[z].bottom,zc,InpZoneFill);
            string zt=(dir<0) ? "Supply" : "Demand";
            if(e.m_zn[z].tested) zt+=" (tested)";
            if(mtf) zt+=" "+tag;
            ObjText(pf+"ZT"+IntegerToString(z),e.m_t[e.m_zn[z].i0],e.m_zn[z].top,zt,zc,7,ANCHOR_LEFT_LOWER);
           }
         else if(InpShowBreakers)
           {
            bool bear=(dir>0);   // broken demand flips to bearish breaker
            if(bear) { if(cBR>=InpZoneCount) continue; cBR++; }
            else     { if(cBB>=InpZoneCount) continue; cBB++; }
            color bc=bear ? InpBearBrkClr : InpBullBrkClr;
            ObjRect(pf+"Z"+IntegerToString(z),e.m_t[e.m_zn[z].iBroken],e.m_zn[z].top,tRight,e.m_zn[z].bottom,bc,false);
            string bt=bear ? "Bear breaker" : "Bull breaker";
            if(mtf) bt+=" "+tag;
            ObjText(pf+"ZT"+IntegerToString(z),e.m_t[e.m_zn[z].iBroken],e.m_zn[z].top,bt,bc,7,ANCHOR_LEFT_LOWER);
           }
        }
     }

   //--- FVG
   if(InpShowFVG)
     {
      int c=0;
      for(int f=e.m_nfv-1;f>=0 && c<InpFVGCount;f--)
        {
         if(e.m_fv[f].filled) continue;
         c++;
         ObjRect(pf+"F"+IntegerToString(f),e.m_t[e.m_fv[f].i0],e.m_fv[f].top,tRight,e.m_fv[f].bottom,
                 (e.m_fv[f].dir>0) ? InpBullFVGClr : InpBearFVGClr,true);
        }
     }

   if(mtf) return;

   //--- measured-move signals
   if(InpShowMM)
     {
      int c=0;
      for(int q=e.m_nmm-1;q>=0 && c<8;q--,c++)
        {
         datetime tm=e.m_t[e.m_mm[q].idx];
         bool bull=(e.m_mm[q].dir>0);
         double px=bull ? e.m_l[e.m_mm[q].idx] : e.m_h[e.m_mm[q].idx];
         color clr=bull ? InpBullClr : InpBearClr;
         ObjArrow(g_pfx+"MA"+IntegerToString(q),tm,px,bull ? 233 : 234,clr,bull ? ANCHOR_TOP : ANCHOR_BOTTOM);
         ObjText(g_pfx+"MQ"+IntegerToString(q),tm,px,"MM Q"+IntegerToString(e.m_mm[q].quality)+" "+DoubleToString(e.m_mm[q].ratio*100.0,1),
                 clr,7,bull ? ANCHOR_UPPER : ANCHOR_LOWER);
         datetime te=(datetime)((long)tm+(long)g_ps*15);
         ObjLine(g_pfx+"MT"+IntegerToString(q),tm,e.m_mm[q].target,te,e.m_mm[q].target,clr,STYLE_DOT,1);
        }
     }

   //--- fib levels of the active range
   if(InpShowFib && e.m_havePH && e.m_havePL && e.m_phPx>e.m_plPx)
     {
      bool up=(e.m_phIdx>e.m_plIdx);
      double range=e.m_phPx-e.m_plPx;
      datetime t0=e.m_t[MathMax(e.m_phIdx,e.m_plIdx)];
      double rat[6];
      rat[0]=0.0; rat[1]=0.236; rat[2]=0.382; rat[3]=0.5; rat[4]=0.618; rat[5]=0.786;
      for(int r=0;r<6;r++)
        {
         double px=up ? (e.m_phPx-rat[r]*range) : (e.m_plPx+rat[r]*range);
         ObjLine(g_pfx+"FB"+IntegerToString(r),t0,px,tRight,px,InpFibClr,STYLE_DOT,1);
         ObjText(g_pfx+"FT"+IntegerToString(r),tRight,px,DoubleToString(rat[r]*100.0,1),InpFibClr,7,ANCHOR_LEFT);
        }
     }
  }

void Lvl(const string id,const double price,const color clr,const ENUM_LINE_STYLE st,const int w,
         const datetime t1,const datetime t2)
  {
   if(price<=0.0 || price==EMPTY_VALUE) return;
   ObjLine(g_pfx+"L_"+id,t1,price,t2,price,clr,st,w);
   ObjText(g_pfx+"LT_"+id,t2,price,id,clr,7,ANCHOR_RIGHT_LOWER);
  }

void DrawLevels(const int n,const datetime &time[],const datetime tRight)
  {
   int last=n-1;
   long key=((long)time[last]-(long)InpDayStartHour*3600)/86400;
   int s=last;
   while(s>0 && (((long)time[s-1]-(long)InpDayStartHour*3600)/86400)==key) s--;
   datetime t1=time[s];
   if(InpShowPDHL)
     {
      Lvl("PDH",bPDH[last],InpLvlPDClr,STYLE_SOLID,1,t1,tRight);
      Lvl("PDL",bPDL[last],InpLvlPDClr,STYLE_SOLID,1,t1,tRight);
     }
   if(InpShowDayHL)
     {
      Lvl("DH",bDH[last],InpLvlDayClr,STYLE_DOT,1,t1,tRight);
      Lvl("DL",bDL[last],InpLvlDayClr,STYLE_DOT,1,t1,tRight);
     }
   if(InpShowYestOC)
     {
      Lvl("YC",bYC[last],InpLvlYClr,STYLE_DASH,1,t1,tRight);
      Lvl("YO",bYO[last],InpLvlYClr,STYLE_DASHDOT,1,t1,tRight);
     }
   if(InpShowIB)
     {
      Lvl("IBH",bIBH[last],InpLvlIBClr,STYLE_DASH,1,t1,tRight);
      Lvl("IBL",bIBL[last],InpLvlIBClr,STYLE_DASH,1,t1,tRight);
     }
   if(InpShowOR)
     {
      Lvl("ORH",bORH[last],InpLvlORClr,STYLE_DASHDOT,1,t1,tRight);
      Lvl("ORL",bORL[last],InpLvlORClr,STYLE_DASHDOT,1,t1,tRight);
     }
  }

void EmitSessionBox(const int s,const datetime t1,const datetime t2,const double hi,const double lo)
  {
   string nm[3];
   nm[0]="Asia"; nm[1]="London"; nm[2]="New York";
   color cl[3];
   cl[0]=InpAsiaClr; cl[1]=InpLondonClr; cl[2]=InpNewYorkClr;
   string id=g_pfx+"S"+IntegerToString(s)+"_"+IntegerToString((long)t1);
   ObjRect(id,t1,hi,(datetime)((long)t2+(long)g_ps),lo,cl[s],false);
   ObjText(id+"t",t1,hi,nm[s],cl[s],7,ANCHOR_LEFT_LOWER);
  }

void DrawSessions(const int n,const datetime &t[],const double &h[],const double &l[])
  {
   datetime tMin=(datetime)((long)t[n-1]-(long)InpSessionDays*86400);
   int i0=n-1;
   while(i0>0 && t[i0-1]>=tMin) i0--;
   long     curKey[3];
   datetime t1[3],t2[3];
   double   hi[3],lo[3];
   bool     act[3];
   for(int s=0;s<3;s++) { act[s]=false; curKey[s]=-1; t1[s]=0; t2[s]=0; hi[s]=0; lo[s]=0; }
   for(int i=i0;i<n;i++)
     {
      int m=(int)(((long)t[i]%86400)/60);
      for(int s=0;s<3;s++)
        {
         if(!InSession(m,s)) continue;
         long key=(long)t[i]/86400;
         if(g_ss[s]>g_se[s] && m<g_se[s]) key--;
         if(act[s] && curKey[s]!=key)
           {
            EmitSessionBox(s,t1[s],t2[s],hi[s],lo[s]);
            act[s]=false;
           }
         if(!act[s])
           {
            act[s]=true; curKey[s]=key; t1[s]=t[i]; t2[s]=t[i]; hi[s]=h[i]; lo[s]=l[i];
           }
         else
           {
            t2[s]=t[i]; hi[s]=MathMax(hi[s],h[i]); lo[s]=MathMin(lo[s],l[i]);
           }
        }
     }
   for(int s=0;s<3;s++)
      if(act[s]) EmitSessionBox(s,t1[s],t2[s],hi[s],lo[s]);
  }

void DrawSqueezeMarks(const int n,const datetime &t[],const double &h[],const double &l[])
  {
   int from=MathMax(0,n-400);
   for(int i=from;i<n-1;i++)
     {
      if(bSqF[i]==0.0) continue;
      bool bull=(bSqF[i]>0.0);
      ObjArrow(g_pfx+"SQ"+IntegerToString(i),t[i],bull ? l[i] : h[i],159,bull ? InpBullClr : InpBearClr,
               bull ? ANCHOR_TOP : ANCHOR_BOTTOM);
     }
  }

//+------------------------------------------------------------------+
//| Alerts on the last closed bar                                    |
//+------------------------------------------------------------------+
void CheckAlerts(const int n,const datetime &t[],const double &close[])
  {
   int c=n-2;
   if(c<2) return;
   if(t[c]<=g_alertBar) return;
   g_alertBar=t[c];
   string head=_Symbol+" "+TfName((ENUM_TIMEFRAMES)_Period)+": ";

   if(InpAlertCHoCH && bCHOCH[c]!=0.0) Notify(head+((bCHOCH[c]>0) ? "Bullish CHoCH" : "Bearish CHoCH"));
   if(InpAlertBOS   && bBOS[c]!=0.0)   Notify(head+((bBOS[c]>0) ? "Bullish BOS" : "Bearish BOS"));
   if(InpAlertMM    && bMM[c]!=0.0)
      Notify(head+((bMM[c]>0) ? "Measured move BUY" : "Measured move SELL")+" Q"+IntegerToString((int)bMMQ[c])+
             " target "+DoubleToString(bMMT[c],_Digits));
   if(InpAlertZone  && bZT[c]!=0.0)    Notify(head+((bZT[c]>0) ? "Price entered demand / bull breaker" : "Price entered supply / bear breaker"));
   if(InpAlertSqueeze && bSqF[c]!=0.0) Notify(head+((bSqF[c]>0) ? "Squeeze fired UP" : "Squeeze fired DOWN"));
   if(InpAlertFVG)
     {
      if(bFVG[c]!=0.0) Notify(head+((bFVG[c]>0) ? "New bullish FVG" : "New bearish FVG"));
      if(g_eng.m_n>0 && g_eng.o_fvgf[g_eng.m_n-1]>0.0) Notify(head+"FVG filled");
     }
   if(InpAlertVWAP)
     {
      bool nowAbove=(close[c]>bVWAP[c]);
      bool preAbove=(close[c-1]>bVWAP[c-1]);
      if(nowAbove && !preAbove) Notify(head+"Price crossed above VWAP");
      if(!nowAbove && preAbove) Notify(head+"Price crossed below VWAP");
     }
  }

//+------------------------------------------------------------------+
//| New-bar processing                                               |
//+------------------------------------------------------------------+
void ProcessStructure(const int n,const bool reset,const datetime &t[],const double &open[],const double &high[],
                      const double &low[],const double &close[])
  {
   int nClosed=n-1;
   bool backfill=false;

   if(reset || nClosed<g_nextChart)
     {
      g_eng.Reset();
      g_eng.m_off=MathMax(0,nClosed-InpMaxBars);
      g_nextChart=g_eng.m_off;
      g_copied=0;
      for(int i=0;i<n;i++) ZeroStructureBuffers(i);
      g_alertBar=t[n-2];
      if(g_useMTF) { g_mtf.Reset(); backfill=true; }
     }

   for(int i=g_nextChart;i<nClosed;i++)
      g_eng.Append(t[i],open[i],high[i],low[i],close[i]);
   g_nextChart=nClosed;

   if(g_useMTF)
     {
      if(SyncMTF()) backfill=true;
      if(backfill) BackfillMTF(n,t);
     }

   for(int j=g_copied;j<g_eng.m_n;j++)
     {
      int ci=g_eng.m_off+j;
      bTrend[ci]=g_eng.o_trend[j]; bBOS[ci]=g_eng.o_bos[j]; bCHOCH[ci]=g_eng.o_choch[j];
      bSWH[ci]=g_eng.o_swh[j];     bSWL[ci]=g_eng.o_swl[j];
      bLSH[ci]=g_eng.o_lsh[j];     bLSL[ci]=g_eng.o_lsl[j];
      bFVG[ci]=g_eng.o_fvg[j];     bZT[ci]=g_eng.o_touch[j];
      bMM[ci]=g_eng.o_mm[j];       bMMQ[ci]=g_eng.o_mmq[j];
      bMMT[ci]=g_eng.o_mmt[j];     bMMS[ci]=g_eng.o_mms[j];
     }
   g_copied=g_eng.m_n;

   int f=n-1;
   ZeroStructureBuffers(f);
   bTrend[f]=bTrend[f-1]; bLSH[f]=bLSH[f-1]; bLSL[f]=bLSL[f-1];
   if(g_useMTF && g_mtf.m_n>0) bMTF[f]=g_mtf.o_trend[g_mtf.m_n-1];

   CheckAlerts(n,t,close);

   if(!g_draw) return;
   ObjectsDeleteAll(0,g_pfx);
   datetime tRight=(datetime)((long)t[n-1]+(long)g_ps*InpExtendBars);
   DrawEngine(g_eng,TfName((ENUM_TIMEFRAMES)_Period),false,tRight);
   if(g_useMTF) DrawEngine(g_mtf,TfName(InpMTF),true,tRight);
   DrawLevels(n,t,tRight);
   if(InpShowSessions) DrawSessions(n,t,high,low);
   if(InpShowSqueeze)  DrawSqueezeMarks(n,t,high,low);
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| OnCalculate                                                      |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],
                const double &high[],const double &low[],const double &close[],const long &tick_volume[],
                const long &volume[],const int &spread[])
  {
   int need=MathMax(InpSwingStrength*2+30,2*InpSqzLen+5);
   if(rates_total<need) return 0;

   int start=(prev_calculated>1) ? prev_calculated-1 : 0;
   CalcBasic(start,rates_total,time,open,high,low,close,tick_volume);

   bool newBar=(prev_calculated==0 || time[rates_total-1]!=g_lastBar);
   if(newBar)
     {
      g_lastBar=time[rates_total-1];
      ProcessStructure(rates_total,(prev_calculated==0),time,open,high,low,close);
     }
   return rates_total;
  }
//+------------------------------------------------------------------+
