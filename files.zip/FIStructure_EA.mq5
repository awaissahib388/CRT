//+------------------------------------------------------------------+
//|                                               FIStructure_EA.mq5 |
//|  Expert Advisor that hosts FIStructure.ex5 through iCustom() and |
//|  trades its BOS / CHoCH / measured-move / zone / squeeze signals.|
//|                                                                  |
//|  Install: compile FIStructure.mq5 first (MQL5\Indicators), then  |
//|  compile this file (MQL5\Experts).                               |
//+------------------------------------------------------------------+
#property copyright "Original implementation"
#property version   "1.00"
#property tester_indicator "FIStructure.ex5"

#include <Trade\Trade.mqh>

//--- buffer map: MUST match FIStructure.mq5
enum FI_BUF
  {
   B_CO=0, B_CH=1, B_CL=2, B_CC=3, B_CCLR=4,
   B_EMA1=5, B_EMA2=6, B_EMA3=7, B_VWAP=8, B_SSLU=9, B_SSLD=10,
   B_TREND=11, B_BOS=12, B_CHOCH=13, B_SWH=14, B_SWL=15, B_LSH=16, B_LSL=17,
   B_SQON=18, B_SQFIRE=19, B_SQMOM=20, B_FVG=21, B_ZTOUCH=22,
   B_MM=23, B_MMQ=24, B_MMT=25, B_MMS=26,
   B_PDH=27, B_PDL=28, B_YC=29, B_YO=30, B_DH=31, B_DL=32, B_DO=33,
   B_IBH=34, B_IBL=35, B_ORH=36, B_ORL=37,
   B_EMABIAS=38, B_MTF=39, B_CUMPV=40, B_CUMV=41, B_SSLHLV=42, B_SQDELTA=43
  };

input group "=== Indicator link ==="
input string InpIndName       = "FIStructure";  // Indicator name (add folder if in a subfolder)
input int    InpSwingStrength = 5;
input int    InpMaxBars       = 1500;
input double InpFVGMinATR     = 0.10;
input double InpFibTolATR     = 0.10;
input int    InpMMMinQuality  = 2;

input group "=== Entry signals ==="
input bool   InpUseMM         = true;    // Measured-move rejection (fib 50/61.8)
input bool   InpUseCHoCH      = true;    // Change of character (reversal)
input bool   InpUseBOS        = false;   // Break of structure (continuation)
input bool   InpUseZone       = false;   // Retest of demand/supply in trend direction
input bool   InpUseSqueeze    = false;   // Squeeze fire in trend direction
input bool   InpNeedEMABias   = true;    // Signal must agree with EMA2 bias
input bool   InpAllowLong     = true;
input bool   InpAllowShort    = true;
input bool   InpCloseOnCHoCH  = true;    // Close open trade on opposite CHoCH

input group "=== Stops & targets ==="
input double InpSLBufferATR   = 0.15;    // Buffer beyond structure stop (x ATR)
input double InpMinSLATR      = 0.5;     // Min SL distance (x ATR) else fallback
input double InpMaxSLATR      = 5.0;     // Max SL distance (x ATR) else fallback
input double InpFallbackSLATR = 1.5;     // Fallback SL distance (x ATR)
input double InpRR            = 2.0;     // Take-profit as R multiple (non-MM trades)
input bool   InpUseMMTarget   = true;    // Use measured-move target (-23.6% ext) as TP
input int    InpATRPeriod     = 14;

input group "=== Position sizing ==="
input double InpFixedLot      = 0.0;     // >0 = fixed lot, 0 = risk based
input double InpRiskPercent   = 1.0;     // % equity risked per trade

input group "=== Trade management ==="
input bool   InpUseBE         = true;
input double InpBEAtR         = 1.0;     // Move SL to break-even after this many R
input double InpBELockPts     = 10;      // Points locked at break-even
input bool   InpUseTrail      = false;
input double InpTrailATR      = 2.0;     // Trailing distance (x ATR), after break-even

input group "=== Filters ==="
input int    InpMaxSpreadPts  = 0;       // 0 = off
input bool   InpUseTime       = false;
input int    InpStartHour     = 8;       // Server hours
input int    InpEndHour       = 22;
input int    InpMaxTradesDay  = 3;       // 0 = unlimited

input group "=== Execution ==="
input long   InpMagic         = 5120001;
input int    InpDeviation     = 20;
input string InpComment       = "FIStructure";

CTrade   g_trade;
int      g_ind=INVALID_HANDLE;
int      g_atr=INVALID_HANDLE;
datetime g_lastBar=0;
int      g_dayKey=-1;
int      g_tradesToday=0;
bool     g_readOk=true;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_ind=iCustom(_Symbol,_Period,InpIndName,InpSwingStrength,InpMaxBars,InpFVGMinATR,InpFibTolATR,InpMMMinQuality);
   if(g_ind==INVALID_HANDLE)
     {
      Print("FIStructure_EA: cannot create indicator '",InpIndName,"' (error ",GetLastError(),
            "). Compile FIStructure.mq5 first.");
      return INIT_FAILED;
     }
   g_atr=iATR(_Symbol,_Period,InpATRPeriod);
   if(g_atr==INVALID_HANDLE) return INIT_FAILED;

   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(InpDeviation);
   g_trade.SetTypeFillingBySymbol(_Symbol);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(g_ind!=INVALID_HANDLE) IndicatorRelease(g_ind);
   if(g_atr!=INVALID_HANDLE) IndicatorRelease(g_atr);
  }

//+------------------------------------------------------------------+
double Buf(const int buffer,const int shift)
  {
   double a[1];
   if(CopyBuffer(g_ind,buffer,shift,1,a)!=1) { g_readOk=false; return 0.0; }
   return a[0];
  }

double Atr(const int shift)
  {
   double a[1];
   if(CopyBuffer(g_atr,0,shift,1,a)!=1) { g_readOk=false; return 0.0; }
   return a[0];
  }

int CountPositions(long &type)
  {
   int cnt=0;
   type=-1;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      cnt++;
      type=PositionGetInteger(POSITION_TYPE);
     }
   return cnt;
  }

bool TimeOk()
  {
   if(!InpUseTime) return true;
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   if(InpStartHour<=InpEndHour) return (dt.hour>=InpStartHour && dt.hour<InpEndHour);
   return (dt.hour>=InpStartHour || dt.hour<InpEndHour);
  }

double NormalizeLots(double lots)
  {
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   double vmin=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(step<=0.0) step=0.01;
   lots=MathFloor(lots/step)*step;
   lots=MathMax(vmin,MathMin(vmax,lots));
   return NormalizeDouble(lots,2);
  }

double CalcLots(const double slDist)
  {
   if(InpFixedLot>0.0) return NormalizeLots(InpFixedLot);
   double tickVal=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tickVal<=0.0 || tickSize<=0.0 || slDist<=0.0) return NormalizeLots(0.01);
   double risk=AccountInfoDouble(ACCOUNT_EQUITY)*InpRiskPercent/100.0;
   double lossPerLot=slDist/tickSize*tickVal;
   return NormalizeLots(risk/lossPerLot);
  }

//+------------------------------------------------------------------+
//| Entry                                                            |
//+------------------------------------------------------------------+
void TryEntry()
  {
   g_readOk=true;
   double mm    =Buf(B_MM,1);
   double mmT   =Buf(B_MMT,1);
   double mmS   =Buf(B_MMS,1);
   double choch =Buf(B_CHOCH,1);
   double bos   =Buf(B_BOS,1);
   double touch =Buf(B_ZTOUCH,1);
   double sqf   =Buf(B_SQFIRE,1);
   double trend =Buf(B_TREND,1);
   double bias  =Buf(B_EMABIAS,1);
   double lsh   =Buf(B_LSH,1);
   double lsl   =Buf(B_LSL,1);
   double atr   =Atr(1);
   if(!g_readOk || atr<=0.0) return;

   //--- opposite CHoCH exit
   long ptype;
   int npos=CountPositions(ptype);
   if(InpCloseOnCHoCH && npos>0 && choch!=0.0)
     {
      if((ptype==POSITION_TYPE_BUY && choch<0.0) || (ptype==POSITION_TYPE_SELL && choch>0.0))
        {
         for(int i=PositionsTotal()-1;i>=0;i--)
           {
            ulong tk=PositionGetTicket(i);
            if(tk==0) continue;
            if(PositionGetString(POSITION_SYMBOL)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
            g_trade.PositionClose(tk);
           }
         npos=CountPositions(ptype);
        }
     }
   if(npos>0) return;

   //--- limits
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   int dk=dt.year*1000+dt.day_of_year;
   if(dk!=g_dayKey) { g_dayKey=dk; g_tradesToday=0; }
   if(InpMaxTradesDay>0 && g_tradesToday>=InpMaxTradesDay) return;
   if(!TimeOk()) return;
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   if(InpMaxSpreadPts>0 && (ask-bid)/_Point>InpMaxSpreadPts) return;

   //--- signal selection (priority: MM, CHoCH, BOS, zone, squeeze)
   int dir=0;
   bool isMM=false;
   if(InpUseMM && mm!=0.0) { dir=(mm>0.0) ? 1 : -1; isMM=true; }
   else if(InpUseCHoCH && choch!=0.0) dir=(choch>0.0) ? 1 : -1;
   else if(InpUseBOS && bos!=0.0) dir=(bos>0.0) ? 1 : -1;
   else if(InpUseZone && touch!=0.0 && ((touch>0.0 && trend>0.0) || (touch<0.0 && trend<0.0))) dir=(touch>0.0) ? 1 : -1;
   else if(InpUseSqueeze && sqf!=0.0 && ((sqf>0.0 && trend>0.0) || (sqf<0.0 && trend<0.0))) dir=(sqf>0.0) ? 1 : -1;
   if(dir==0) return;
   if(dir>0 && !InpAllowLong) return;
   if(dir<0 && !InpAllowShort) return;
   if(InpNeedEMABias && ((dir>0 && bias<0.0) || (dir<0 && bias>0.0))) return;

   //--- stops and targets
   double entry=(dir>0) ? ask : bid;
   double sl=0.0;
   if(isMM && mmS>0.0) sl=(dir>0) ? mmS-InpSLBufferATR*atr : mmS+InpSLBufferATR*atr;
   else if(dir>0 && lsl>0.0) sl=lsl-InpSLBufferATR*atr;
   else if(dir<0 && lsh>0.0) sl=lsh+InpSLBufferATR*atr;

   double dist=(sl>0.0) ? MathAbs(entry-sl) : 0.0;
   bool wrongSide=(sl>0.0) && ((dir>0 && sl>=entry) || (dir<0 && sl<=entry));
   if(sl<=0.0 || wrongSide || dist<InpMinSLATR*atr || dist>InpMaxSLATR*atr)
     {
      dist=InpFallbackSLATR*atr;
      sl=(dir>0) ? entry-dist : entry+dist;
     }
   double minDist=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   if(dist<minDist)
     {
      dist=minDist+_Point;
      sl=(dir>0) ? entry-dist : entry+dist;
     }

   double tp=(dir>0) ? entry+InpRR*dist : entry-InpRR*dist;
   if(isMM && InpUseMMTarget && mmT>0.0)
     {
      bool okSide=(dir>0 && mmT>entry+minDist) || (dir<0 && mmT<entry-minDist);
      if(okSide) tp=mmT;
     }

   sl=NormalizeDouble(sl,_Digits);
   tp=NormalizeDouble(tp,_Digits);
   double lots=CalcLots(dist);
   bool ok=(dir>0) ? g_trade.Buy(lots,_Symbol,0.0,sl,tp,InpComment)
                   : g_trade.Sell(lots,_Symbol,0.0,sl,tp,InpComment);
   if(ok) g_tradesToday++;
   else Print("FIStructure_EA: order failed, retcode=",g_trade.ResultRetcode()," ",g_trade.ResultRetcodeDescription());
  }

//+------------------------------------------------------------------+
//| Break-even / trailing                                            |
//+------------------------------------------------------------------+
void ManagePositions()
  {
   if(!InpUseBE && !InpUseTrail) return;
   double atr=Atr(1);
   double stopLvl=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      long   type=PositionGetInteger(POSITION_TYPE);
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double tp=PositionGetDouble(POSITION_TP);
      double price=(type==POSITION_TYPE_BUY) ? SymbolInfoDouble(_Symbol,SYMBOL_BID) : SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double newSL=sl;

      if(type==POSITION_TYPE_BUY)
        {
         double risk=open-sl;
         bool beDone=(sl>=open);
         if(InpUseBE && !beDone && risk>0.0 && (price-open)>=InpBEAtR*risk)
            newSL=open+InpBELockPts*_Point;
         if(InpUseTrail && (beDone || newSL>=open) && atr>0.0)
           {
            double ts=price-InpTrailATR*atr;
            if(ts>newSL) newSL=ts;
           }
         if(newSL>sl+_Point && (price-newSL)>stopLvl)
            g_trade.PositionModify(tk,NormalizeDouble(newSL,_Digits),tp);
        }
      else
        {
         double risk=sl-open;
         bool beDone=(sl>0.0 && sl<=open);
         if(InpUseBE && !beDone && risk>0.0 && (open-price)>=InpBEAtR*risk)
            newSL=open-InpBELockPts*_Point;
         if(InpUseTrail && (beDone || (newSL<=open && newSL>0.0)) && atr>0.0)
           {
            double ts=price+InpTrailATR*atr;
            if(newSL<=0.0 || ts<newSL) newSL=ts;
           }
         if(newSL>0.0 && (sl<=0.0 || newSL<sl-_Point) && (newSL-price)>stopLvl)
            g_trade.PositionModify(tk,NormalizeDouble(newSL,_Digits),tp);
        }
     }
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   if(BarsCalculated(g_ind)<=0) return;

   ManagePositions();

   datetime t0=iTime(_Symbol,_Period,0);
   if(t0==g_lastBar) return;
   g_lastBar=t0;
   TryEntry();
  }
//+------------------------------------------------------------------+
